import React from "react";
import "../index.css";



export default function Beranda_Menu() {
  return (
    <div className="fixed flex flex-col bg-[#CBF3BB] min-w-screen h-screen flex justify-center items-center">
    
         <img src="/Matematix.png" alt="judul_halaman_home" className="transform -translate-y-80 transition-all duration-500"/>


        <div className="flex flex-col items-center mb-[-250px] ">
           <div className="flex flex-row mt-4 min-w-screen h-50 items-end">
               <img src="/rumput.png" alt="rumput"
               className=" h-200 w-200 ml-[-120px] z-10 mb-[-20px]"
               />

               <img src="/dino_1.png" alt="dino"
               className="relative ml-[-670px] z-0  mb-[-20px]"
               />

               <img src="/rumput.png" alt="rumput"
                className=" h-200 w-200 ml-[-20px] ml-[960px]"  
               />                
           </div>
        </div>
    </div>
  );
}